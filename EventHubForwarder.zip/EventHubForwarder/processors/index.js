const MetricsProcessor = require('./metrics-processor');

module.exports = {
  MetricsProcessor,
};
