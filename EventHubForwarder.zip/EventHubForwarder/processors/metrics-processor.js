const process = async (messages) => messages.length;

module.exports = {
    process,
}
